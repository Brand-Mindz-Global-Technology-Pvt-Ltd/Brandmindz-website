const mysql = require('mysql2');
const { queryWithRetry } = require('../services/queryWithRetry.js');

const isProduction = process.env.NODE_ENV === 'production';
const requiredProductionVariables = ['DB_HOST', 'DB_USER', 'DB_NAME'];
const missingProductionVariables = requiredProductionVariables.filter(
    (name) => !String(process.env[name] || '').trim()
);
const hasProductionPasswordVariable = Boolean(
    Object.prototype.hasOwnProperty.call(process.env, 'DB_PASSWORD')
    && String(process.env.DB_PASSWORD).length > 0
);

if (isProduction && (missingProductionVariables.length || !hasProductionPasswordVariable)) {
    const missingVariables = [
        ...missingProductionVariables,
        ...(!hasProductionPasswordVariable ? ['DB_PASSWORD'] : [])
    ];
    throw new Error(
        `Missing required production database variables: ${missingVariables.join(', ')}`
    );
}

// Local defaults are intentionally available only for development. Production
// must receive the live database configuration from the deployment environment.
const databaseConfig = {
    host: String(process.env.DB_HOST || 'localhost').trim(),
    port: Number(process.env.DB_PORT || 3306),
    user: String(process.env.DB_USER || 'root').trim(),
    password: process.env.DB_PASSWORD || '',
    database: String(process.env.DB_NAME || 'brandmindz').trim(),
    ...(process.env.DB_SSL === 'true' ? { ssl: { rejectUnauthorized: true } } : {})
};

const pool = mysql.createPool({
    ...databaseConfig,
    waitForConnections: true,
    connectionLimit: Number(process.env.DB_CONNECTION_LIMIT || 10),
    maxIdle: Number(process.env.DB_MAX_IDLE || 5),
    idleTimeout: Number(process.env.DB_IDLE_TIMEOUT_MS || 60000),
    queueLimit: 0,
    connectTimeout: Number(process.env.DB_CONNECT_TIMEOUT_MS || 10000),
    enableKeepAlive: true,
    keepAliveInitialDelay: 10000
});

console.log(
    `[MySQL] Configured host=${databaseConfig.host}:${databaseConfig.port} `
    + `user=${databaseConfig.user} database=${databaseConfig.database}`
);

// Check configuration at startup without leaving the application tied to one
// connection. Pool queries can acquire a fresh connection after a DB restart.
pool.getConnection((err, connection) => {
    if (err) {
        console.error(`[MySQL] Initial connection failed (${err.code || 'UNKNOWN'}): ${err.message}`);
        return;
    }

    console.log('Connected to MySQL database successfully.');
    connection.release();
});

function query(sql, values, callback) {
    let queryValues = values;
    let queryCallback = callback;

    if (typeof values === 'function') {
        queryCallback = values;
        queryValues = undefined;
    }

    if (typeof queryCallback !== 'function') {
        throw new TypeError('Database query callback is required');
    }

    const queryArgs = queryValues === undefined ? [sql] : [sql, queryValues];

    return queryWithRetry(
        pool.query.bind(pool),
        queryArgs,
        queryCallback,
        // A DB restart or a stale Docker-to-host connection can take more than
        // a few hundred milliseconds to recover. Each retry acquires a fresh
        // pooled connection.
        { maxRetries: 5, retryDelayMs: 300 }
    );
}

module.exports = {
    query,
    escape: mysql.escape,
    getConnection: pool.getConnection.bind(pool)
};
